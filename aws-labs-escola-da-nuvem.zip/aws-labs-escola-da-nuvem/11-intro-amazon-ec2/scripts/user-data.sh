#!/bin/bash
# User data usado no Lab 11 - Introdução ao Amazon EC2
# Executado automaticamente na primeira inicialização da instância.

# Instala o servidor web Apache (httpd)
yum -y install httpd

# Configura o Apache para iniciar junto com o sistema
systemctl enable httpd

# Inicia o Apache agora
systemctl start httpd

# Cria uma página web simples
echo '<html><h1>Hello From Your Web Server!</h1></html>' > /var/www/html/index.html
