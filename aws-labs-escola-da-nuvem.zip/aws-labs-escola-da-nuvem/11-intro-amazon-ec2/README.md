# Lab 11 - Introdução ao Amazon EC2

Laboratório da formação em Computação em Nuvem e IA da **Escola da Nuvem**.
Neste lab, executei, monitorei, redimensionei e encerrei uma instância Amazon EC2 rodando um servidor web Apache.

## Objetivos

- Iniciar um servidor web com proteção contra encerramento ativada
- Monitorar a instância do EC2
- Modificar o grupo de segurança para permitir acesso HTTP
- Redimensionar a instância (tipo e volume EBS)
- Testar a proteção contra encerramento
- Encerrar a instância

**Duração estimada:** 45 minutos

## Serviços AWS utilizados

| Serviço | Uso no lab |
|---|---|
| Amazon EC2 | Instância do servidor web |
| Amazon EBS | Volume raiz (8 GiB -> 10 GiB) |
| Security Groups | Firewall virtual da instância |
| Amazon VPC | Rede da instância (Lab VPC) |
| Amazon CloudWatch | Métricas de monitoramento |

## Arquitetura

```
Internet --> (HTTP :80) --> Security Group --> EC2 (Amazon Linux 2023 + Apache) --> EBS
                                  \_______________ Lab VPC _______________/
```

## Passo a passo

### Tarefa 1 - Iniciar a instância EC2

| Configuração | Valor |
|---|---|
| Nome | `Web Server` |
| AMI | Amazon Linux 2023 |
| Tipo de instância | `t3.micro` (2 vCPUs, 1 GiB) |
| Par de chaves | Sem par de chaves (o lab não usa SSH) |
| VPC | Lab VPC |
| Security group | `Web Server security group` (sem regras de entrada) |
| Armazenamento | 8 GiB (padrão) |
| Proteção contra encerramento | Habilitada |
| User data | [`scripts/user-data.sh`](scripts/user-data.sh) |

O script de user data instala o Apache, habilita e inicia o serviço e cria uma página `index.html` simples.

Resultado esperado: estado **Em execução** e **2/2 verificações de status aprovadas**.

![Instância em execução](prints/01-instancia-em-execucao.png)

### Tarefa 2 - Monitorar a instância

- Aba **Status checks**: System reachability e Instance reachability aprovadas
- Aba **Monitoring**: métricas do CloudWatch (monitoramento básico a cada 5 min; o detalhado é de 1 min)
- **Ações > Monitorar e solucionar problemas > Get Instance Screenshot**: captura de tela do console da instância

![Monitoramento](prints/02-monitoramento.png)

### Tarefa 3 - Atualizar o security group e acessar o servidor web

1. Acessei o IPv4 público da instância no navegador: **não carregou**, pois o security group não tinha regra de entrada para a porta 80.
2. Em **Security Groups > Web Server security group > Inbound rules**, adicionei a regra:
   - Tipo: `HTTP`
   - Origem: `IPv4 em qualquer lugar`
3. Atualizei a página e apareceu **Hello From Your Web Server!**.

![Página do servidor web](prints/03-servidor-web.png)

### Tarefa 4 - Redimensionar a instância

1. **Interromper** a instância (instância parada não gera cobrança de computação, mas o EBS continua sendo cobrado).
2. **Ações > Configurações de instância > Alterar tipo de instância**: `t3.micro` -> `t3.small` (o dobro de memória).
3. **Elastic Block Store > Volumes > Modificar volume**: `8 GiB` -> `10 GiB`.
4. **Iniciar** a instância novamente.

![Instância redimensionada](prints/04-redimensionamento.png)

### Tarefa 5 - Testar a proteção contra encerramento

1. Tentei encerrar a instância e a operação **falhou**, porque a proteção contra encerramento estava ativada.
2. Em **Ações > Configurações de instância > Change termination protection**, desmarquei **Enable** e salvei.
3. Encerrei a instância com sucesso.

![Proteção contra encerramento](prints/05-protecao-encerramento.png)

## Aprendizados

- **Security groups** funcionam como firewall: sem regra de entrada, nenhum tráfego chega à instância.
- **User data** automatiza a configuração inicial da instância (aqui, a instalação de um servidor web).
- Para **redimensionar** o tipo da instância e o volume, é preciso interromper a instância primeiro.
- A **proteção contra encerramento** evita a exclusão acidental de instâncias.
- Instância parada não cobra computação, mas volumes EBS conectados continuam sendo cobrados.

## Estrutura da pasta

```
11-intro-amazon-ec2/
├── README.md
├── prints/
└── scripts/
    └── user-data.sh
```
